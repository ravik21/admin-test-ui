$(function () {
    $('#aniimated-thumbnials').lightGallery({
        thumbnail: true,
        selector: 'a'
    });
    $('#aniimated-thumbnials1').lightGallery({
        thumbnail: true,
        selector: 'a'
    });
});